# DOMPurifyNodeLambda
does what it says on the tin... a node project to espose basic domPurify functionality for use in an aws lambda
